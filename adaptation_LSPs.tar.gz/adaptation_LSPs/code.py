import time
f = open('/home/hoangcuong2011/Desktop/adaptation_LSPs/code_vectors')
line = f.readline()

f_1 = open('/home/hoangcuong2011/Desktop/adaptation_LSPs/cust-05-es-en.tgt')
line_1 = f_1.readline()

signalOLD = 0
signalNEW = 0
agreement = 0
disagreement = 0

text = ""
line1 = True
line2 = False
file = open("statistics.txt","w") 
while line:
	line = line.strip()
	line_1 = line_1.strip()
	if len(line) == 0:
		print("it happaens")
		line = f.readline()
		continue
	arr = line.split()
	#print(len(arr))

	if len(arr)==4096:
		text = line.replace(" ",",")
		file.write(text+",\n")
		if line1==True:
			#ok
			line1 = False
			line2 = True
		else: 
			print("it happens 1")
			line2 = True
			line1 = False
	
	else:
		#print(line)
		if line_1.strip() != line.strip():
			arr = line.split()
			print(line)
			print(line_1)
			#print(line)
			print(len(arr))
			print("error")
			
		line_1 = f_1.readline()		
		if line2==True:
			#ok
			line1 = True
			line2 = False
		else: 
			print("it happens")
			print(line)
			line2 = False
			line1 = True
	line = f.readline()

f.close()
file.close()
print("Total agreement: ", agreement)

print("Total disagreement: ", disagreement)

